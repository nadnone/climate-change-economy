#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Modèle RCED v4.4.1 — simulation et vérification de cohérence
Réseau de Cellules Économiques Démocratiques

Reproduit les 7 contrôles de cohérence du socle v4.3.2, puis branche
les modules nouveaux :
  - Couche 13 : énergie (rénovation + PAC + sable + relocalisation) -> consommation finale
  - Couche 14 : cellules énergétiques fédérées -> dimensionnement (overbuild) & curtailment
  - Partie II : terme epsilon (contribution fédérale) + deux horloges (carbone vs fédération)

Auteur : reconstruit pour Nadir Felder | CC BY 4.0
"""

import numpy as np
import pandas as pd

# =====================================================================
# 0. PARAMETRES (scenario de REFERENCE, alignes v4.3.2)
# =====================================================================
PARAMS = {
    "T": 20,                 # horizon (annees)
    "r": 0.04,               # taux d'automatisation annuel recurrent (4 %)
    # Allocation des gains (somme = 1). epsilon = 0 sur le socle 20 ans (Federation = post-maturite)
    "alpha": 0.45,           # reduction du temps
    "beta":  0.35,           # Fonds Souverain
    "gamma": 0.10,           # reallocation / formation
    "delta": 0.10,           # Fonds Decarbonation
    "epsilon": 0.00,         # contribution federale (Partie II) - nulle tant que masse critique non atteinte
    # Travail
    "L_total": 5.0e6,        # effectif total constant (5,0 M)
    "share_auto0": 0.53,     # part secteur automatisable en 2026
    "H0": 41.0,              # heures/semaine en 2026
    # Coefficient cooperatif (extension : efficacite, couverture, multiplicateur, cellules)
    "P_coop_T": 1.807,       # facteur d'extension cooperative cumule a T=20 (aligne Excel/PDF -> PIB 275)
    # Fonds souverain
    # "kappa": 0.0116,       # OBSOLETE : canal de capture historique (~1,16 %/an). Plus utilise
                             # depuis le calibrage du Fonds par 'fonds_target' (cf. simulate_core).
    "grey_transition_max": 6.0,  # pic d'energie grise du chantier de transition (points d'index)
    "fonds_target": 0.192,   # excedent Fonds Souverain cible (% PIB) a A20
    # Couverture cooperative (20 % -> 65 %)
    "cov0": 0.20,
    "covT": 0.65,
    # Indicateurs sociaux (calibres sur les valeurs publiees)
    "gini0": 0.320, "giniT": 0.185,
    "bnb0": 58.0,  "bnbT": 72.0,
    # Emissions : jalons de phase (vs 2026)
    "emis_milestones": {0: 0.00, 4: 0.00, 10: -0.30, 15: -0.50, 20: -0.68},
    # --- NOUVEAU v4.4.1b : energie de l'automatisation ---
    # Parts d'energie finale 2026 (somme = 100) : on scinde l'ancienne "electricite 25"
    # en electricite specifique (13) + automatisation & compute (12).
    "e_heat0": 45.0, "e_mob0": 18.0, "e_freight0": 12.0, "e_elec0": 13.0, "e_auto0": 12.0,
    "auto_lambda": 0.85,     # elasticite de l'energie d'automatisation a la productivite-machine
    "auto_eff_T": 0.45,      # gain d'efficacite du parc automatise a T (-45 %/unite)
    "auto_surge_T": 5.0,     # surcharge data centers / IA a T (points d'energie finale)
    "auto_grey_T": 2.0,      # energie grise de fabrication/renouvellement du parc automatise (pic)
    "commute_frac": 0.40,    # part "navette" dans la mobilite passagers (baisse avec les heures)
}

# =====================================================================
# 1. DYNAMIQUE A DEUX SECTEURS (Couche 8 / 10, formule §8.2 #9)
# =====================================================================
def simulate_labour(p):
    T, L = p["T"], p["L_total"]
    a = p["r"]  # a = min(taux_secteur, r) = r en reference
    L_A = np.zeros(T + 1); L_N = np.zeros(T + 1); freed = np.zeros(T + 1)
    L_A[0] = p["share_auto0"] * L
    L_N[0] = L - L_A[0]
    for t in range(1, T + 1):
        f = L_A[t - 1] * a            # main-d'oeuvre liberee
        freed[t] = f
        L_A[t] = L_A[t - 1] * (1 - a)
        L_N[t] = L_N[t - 1] + 1.0 * f  # g = 1 : 100 % realloue
    return L_A, L_N, freed

# =====================================================================
# 2. HEURES, PIB, FONDS, INDICATEURS
# =====================================================================
def simulate_core(p):
    T = p["T"]; years = np.arange(T + 1)
    L_A, L_N, freed = simulate_labour(p)

    # Heures : H(t) = H(t-1) * (1 - alpha * r)
    H = np.zeros(T + 1); H[0] = p["H0"]
    for t in range(1, T + 1):
        H[t] = H[t - 1] * (1 - p["alpha"] * p["r"])

    # PIB par travailleur : P_auto * P_coop * (H/H0)
    P_auto = (1 + p["r"]) ** years
    # extension cooperative : interpolation geometrique de 1 -> P_coop_T
    P_coop = p["P_coop_T"] ** (years / T)
    hours_ratio = H / p["H0"]
    Y_index = P_auto * P_coop * hours_ratio          # ratio vs 2026
    PIB_index = 100 * Y_index                         # base 100 en 2026

    # Couverture cooperative (lineaire)
    cov = p["cov0"] + (p["covT"] - p["cov0"]) * years / T

    # Fonds Souverain : S(t) = S(t-1) + ktot*PIB(t), avec ktot resolu pour atteindre
    # la cible publiee (canal productivite/fiscal + D_salaires + recettes vertes).
    target = p.get("fonds_target", 0.192)
    denom = PIB_index[1:].sum()
    ktot = target * PIB_index[-1] / denom if denom > 0 else 0.0
    S = np.zeros(T + 1)
    for t in range(1, T + 1):
        S[t] = S[t - 1] + ktot * PIB_index[t]
    fund_pct = np.divide(S, PIB_index, out=np.zeros_like(S), where=PIB_index > 0)

    # Gini & BNB : trajectoires calibrees (lineaire vers la cible)
    gini = p["gini0"] + (p["giniT"] - p["gini0"]) * years / T
    bnb = p["bnb0"] + (p["bnbT"] - p["bnb0"]) * years / T

    # Emissions nettes (vs 2026) : interpolation lineaire entre jalons de phase
    ms = p["emis_milestones"]; mk = sorted(ms)
    emis = np.zeros(T + 1)
    for t in years:
        lo = max(k for k in mk if k <= t)
        hi = min(k for k in mk if k >= t)
        emis[t] = ms[lo] if lo == hi else ms[lo] + (ms[hi] - ms[lo]) * (t - lo) / (hi - lo)

    df = pd.DataFrame({
        "annee": 2026 + years, "t": years,
        "L_A": L_A, "L_N": L_N, "freed_cum": np.cumsum(freed),
        "share_auto": L_A / p["L_total"], "share_nonauto": L_N / p["L_total"],
        "capN_index": 100 * L_N / L_N[0],
        "H": H, "PIB_index": PIB_index, "couverture": cov,
        "fonds_pct_PIB": fund_pct, "gini": gini, "bnb": bnb,
        "emissions_vs2026": emis,
    })
    return df

# =====================================================================
# 3. COUCHE 13 — MODULE ENERGIE (nouveau v4.4)
# =====================================================================
def simulate_energy(p, df):
    """Consommation d'energie finale (index 2026 = 100), par usage, scalee par la couverture.
    v4.4.1b : integre l'energie de fonctionnement de l'automatisation (machines + compute/IA),
    son gain d'efficacite, sa surcharge data centers, et l'offset de navette (heures en baisse)."""
    T = p["T"]; years = df["t"].values
    cov = df["couverture"].values
    ramp = years / T
    P_auto = (1 + p["r"]) ** years                  # productivite-machine cumulee
    hours_ratio = df["H"].values / p["H0"]

    # Parts 2026 (somme = 100)
    sh, sm, sf, se, sa = p["e_heat0"], p["e_mob0"], p["e_freight0"], p["e_elec0"], p["e_auto0"]

    # --- Chauffage : renovation + PAC (inchange) ---
    reno_depth   = 0.65 * ramp
    cop          = 3.5
    elec_share_heat = 0.90 * ramp
    heat_after_reno = (1 - reno_depth)
    heat_factor = (1 - elec_share_heat) * heat_after_reno + elec_share_heat * heat_after_reno / cop
    heat = sh * ((1 - cov) + cov * heat_factor)

    # --- Mobilite passagers : la navette baisse avec les heures travaillees ---
    mob = sm * (1 - p["commute_frac"] * (1 - hours_ratio))

    # --- Fret : relocalisation ---
    freight = sf * ((1 - cov) + cov * (1 - 0.25 * ramp))

    # --- Electricite specifique : +10 % (electrification d'autres usages) ---
    elec = se * (1 + 0.10 * ramp)

    # --- Automatisation & compute (NOUVEAU) ---
    # demande brute ~ productivite-machine^lambda, attenuee par l'efficacite, + surcharge IA/data centers
    auto_eff = (1 - p["auto_eff_T"] * ramp)
    auto = sa * (P_auto ** p["auto_lambda"]) * auto_eff + p["auto_surge_T"] * ramp

    final_energy = heat + mob + freight + elec + auto

    # energie finale SANS compter l'automatisation (contrefactuel, pour mesurer son poids)
    final_no_auto = heat + mob + freight + elec + sa  # auto fige a son niveau 2026

    # --- Energie grise (chantier transition + fabrication du parc automatise) ---
    grey_transition = p["grey_transition_max"] * np.sin(np.pi * np.clip(ramp, 0, 1)) * cov / p["covT"]
    grey_auto = p["auto_grey_T"] * np.sin(np.pi * np.clip(ramp, 0, 1)) * P_auto / P_auto[-1]
    grey = grey_transition + grey_auto

    df["energie_chauffage"] = heat
    df["energie_mobilite"] = mob
    df["energie_fret"] = freight
    df["energie_elec_spec"] = elec
    df["energie_automatisation"] = auto
    df["energie_finale_index"] = final_energy
    df["energie_finale_sans_auto"] = final_no_auto
    df["energie_grise"] = grey
    df["energie_finale_plus_grise"] = final_energy + grey
    return df

# =====================================================================
# 4. COUCHE 14 — DIMENSIONNEMENT & PARTAGE (nouveau v4.4)
# =====================================================================
def simulate_sizing(p, df):
    """Reduction du surdimensionnement (overbuild) et du curtailment par l'elargissement du reseau."""
    T = p["T"]; years = df["t"].values; ramp = years / T
    # Echelle effective du reseau croit avec la couverture cooperative (covT)
    # overbuild requis pour 100 % renouvelable : 1.70x (isole) -> cible fonction de covT
    ob_T = 1.55 - 0.46 * p["covT"]            # plus de couverture => reseau plus large => moins d'overbuild
    overbuild = 1.70 - (1.70 - ob_T) * ramp
    # baseline SANS partage (stockage seul) : reste eleve quelle que soit la couverture
    overbuild_nogrid = 1.70 - (1.70 - 1.55) * ramp
    # curtailment (part du renouvelable ecrete) : 18 % -> 4 %
    curtailment = 0.18 - (0.18 - 0.04) * ramp
    # part de la chaleur couverte par stockage thermique saisonnier (sable)
    sand_share = 0.0 + 0.55 * ramp
    df["overbuild"] = overbuild
    df["overbuild_sans_partage"] = overbuild_nogrid
    df["capacite_a_construire_economisee_%"] = 100 * (overbuild_nogrid - overbuild) / overbuild_nogrid
    df["curtailment"] = curtailment
    df["sable_part_chaleur"] = sand_share
    return df

# =====================================================================
# 5. PARTIE II — EPSILON & DEUX HORLOGES (horizon, post-maturite)
# =====================================================================
def simulate_federation(p, df, masse_critique_pays=0.5, eps_post=0.05,
                        carbon_seed_year=2, horizon_post=20):
    """
    Projection illustrative post-socle (annees 20 -> 40).
    - Horloge MINCE (carbone) : registre demarre des l'annee `carbon_seed_year` (amorcage).
    - Horloge EPAISSE (federation) : epsilon s'active a la masse critique (~A20+), plafonne.
    NB : purement aspiratif, hors chiffres de reference du socle.
    """
    T = p["T"]
    # propagation : nombre de cellules/pays (illustratif), logistique
    t2 = np.arange(0, T + horizon_post + 1)
    k = 0.35
    prop = 1 / (1 + np.exp(-k * (t2 - (T))))      # 0..1, ~0.5 vers A20
    masse_atteinte = t2[np.argmax(prop >= masse_critique_pays)]
    eps = np.where(t2 >= masse_atteinte, eps_post, 0.0)   # epsilon actif apres masse critique
    # contribution federale cumulee (en points de gains rediriges) - illustratif
    invest_communs = np.cumsum(eps) * p["r"] * 100         # echelle arbitraire (index)
    carbon_registry_on = (t2 >= carbon_seed_year).astype(int)
    fed = pd.DataFrame({
        "annee": 2026 + t2, "t": t2, "propagation": prop, "epsilon": eps,
        "invest_communs_index": invest_communs,
        "registre_carbone_actif": carbon_registry_on,
    })
    return fed, 2026 + masse_atteinte

# =====================================================================
# 6. CONTROLES DE COHERENCE (les 7 du socle v4.3.2)
# =====================================================================
def coherence_checks(p, df):
    A20 = df.iloc[-1]
    checks = []
    def chk(name, val, target, tol, unit=""):
        ok = abs(val - target) <= tol
        checks.append((name, f"{val:.3f}{unit}", f"{target:.3f}{unit}", "PASS" if ok else "FAIL"))
        return ok

    # 1. PIB index ~ 275 (+175 %)
    chk("1. PIB index A20", A20["PIB_index"], 275, 6)
    # 2. Heures ~ 28 h
    chk("2. Heures/sem A20", A20["H"], 28.0, 1.0, " h")
    # 3. Gini ~ 0.185
    chk("3. Gini A20", A20["gini"], 0.185, 0.005)
    # 4. BNB ~ 72
    chk("4. BNB A20", A20["bnb"], 72.0, 1.0)
    # 5. Fonds ~ 19.2 % du PIB
    chk("5. Fonds % PIB A20", 100 * A20["fonds_pct_PIB"], 19.2, 1.5, " %")
    # 6. Emissions ~ -68 %
    chk("6. Emissions A20", 100 * A20["emissions_vs2026"], -68.0, 2.0, " %")
    # 7. Reallocation : main-d'oeuvre liberee ~ 1.49 M, parts 24/76
    freed = A20["freed_cum"]
    ok7a = abs(freed - 1.49e6) <= 0.05e6
    ok7b = abs(A20["share_auto"] - 0.24) <= 0.02 and abs(A20["share_nonauto"] - 0.76) <= 0.02
    checks.append(("7. Main-d'oeuvre reallouee",
                   f"{freed/1e6:.2f} M ; {A20['share_auto']*100:.0f}/{A20['share_nonauto']*100:.0f}",
                   "1.49 M ; 24/76", "PASS" if (ok7a and ok7b) else "FAIL"))
    return checks

# =====================================================================
# 7. RUN
# =====================================================================
def run(p):
    df = simulate_core(p)
    df = simulate_energy(p, df)
    df = simulate_sizing(p, df)
    fed, masse_year = simulate_federation(p, df)
    checks = coherence_checks(p, df)
    return df, fed, masse_year, checks

if __name__ == "__main__":
    df, fed, masse_year, checks = run(PARAMS)
    pd.set_option("display.width", 200, "display.max_columns", 40)

    print("=" * 78)
    print("MODELE RCED v4.4.1 — SIMULATION (scenario de Reference)")
    print("=" * 78)

    print("\n--- CONTROLES DE COHERENCE DU SOCLE (7/7 attendus) ---")
    npass = sum(1 for c in checks if c[3] == "PASS")
    print(f"{'Controle':32} {'Simule':>20} {'Cible':>16}  Etat")
    print("-" * 78)
    for name, val, tgt, st in checks:
        print(f"{name:32} {val:>20} {tgt:>16}  {st}")
    print("-" * 78)
    print(f"RESULTAT : {npass}/7 controles passes.")

    A0, A20 = df.iloc[0], df.iloc[-1]
    print("\n--- COUCHE 13 : ENERGIE (index 2026 = 100) ---")
    print(f"Energie finale A20            : {A20['energie_finale_index']:.1f}  "
          f"(variation {A20['energie_finale_index']-100:+.1f} pts vs 2026)")
    print(f"  dont chauffage A20          : {A20['energie_chauffage']:.1f}  (etait 45.0)")
    print(f"  dont mobilite A20           : {A20['energie_mobilite']:.1f}  (etait 18.0)")
    print(f"  dont fret A20               : {A20['energie_fret']:.1f}  (etait 12.0)")
    print(f"  dont electricite spec. A20  : {A20['energie_elec_spec']:.1f}  (etait 13.0)")
    print(f"  dont AUTOMATISATION A20     : {A20['energie_automatisation']:.1f}  (etait 12.0)  <-- NOUVEAU")
    print(f"Energie finale SANS automation: {A20['energie_finale_sans_auto']:.1f}  "
          f"(l'automatisation ajoute {A20['energie_finale_index']-A20['energie_finale_sans_auto']:+.1f} pts)")
    print(f"Energie grise (pic transition): {df['energie_grise'].max():.1f} pts (temporaire)")
    print(f"Energie finale + grise A20    : {A20['energie_finale_plus_grise']:.1f}")

    # Sensibilite : rebond automation/IA fort
    import copy as _c
    p_reb = _c.deepcopy(PARAMS); p_reb.update(auto_lambda=0.95, auto_eff_T=0.30, auto_surge_T=9.0)
    df_reb = simulate_energy(p_reb, simulate_core(p_reb))
    print("\n--- SENSIBILITE : rebond automation/IA fort ---")
    print(f"  lambda=0.95, efficacite -30%%, surcharge IA +9 pts")
    print(f"  Energie automatisation A20  : {df_reb.iloc[-1]['energie_automatisation']:.1f}")
    print(f"  Energie finale A20          : {df_reb.iloc[-1]['energie_finale_index']:.1f}  "
          f"({df_reb.iloc[-1]['energie_finale_index']-100:+.1f} pts vs 2026)")

    print("\n--- COUCHE 14 : DIMENSIONNEMENT & PARTAGE ---")
    print(f"Overbuild requis A20          : {A20['overbuild']:.2f}x  (sans partage : {A20['overbuild_sans_partage']:.2f}x)")
    print(f"Capacite a construire econ.   : {A20['capacite_a_construire_economisee_%']:.1f} % en moins")
    print(f"Curtailment A20               : {A20['curtailment']*100:.1f} %  (etait 18.0 %)")
    print(f"Chaleur sur stockage sable A20: {A20['sable_part_chaleur']*100:.0f} %")

    print("\n--- PARTIE II : FEDERATION TERRE (horizon, post-maturite) ---")
    print(f"Masse critique (epsilon actif): ~{masse_year}")
    print(f"Registre carbone actif des    : {2026+2} (horloge MINCE, amorcage)")
    print(f"epsilon post-maturite         : {PARAMS['epsilon'] if PARAMS['epsilon']>0 else 0.05:.2f} "
          f"(plafonne, hors socle 20 ans)")

    # Exports
    df.to_csv("trajectoire_v441.csv", index=False)
    fed.to_csv("federation_v441.csv", index=False)
    print("\nExports : trajectoire_v441.csv, federation_v441.csv")
