#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Scenarios (Conservateur / Reference / Optimiste) + dashboard graphique v4.4.1."""
import copy
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from model_v441 import PARAMS, run

# ---- styles ----
BLUE, BLUE2, GREEN, ORANGE, GREY = "#1F4E79", "#2E75B6", "#2E7D32", "#B85C00", "#888888"
plt.rcParams.update({"font.size": 10, "axes.edgecolor": "#cccccc",
                     "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": .7,
                     "axes.spines.top": False, "axes.spines.right": False})

# ---- definition des scenarios (cibles alignees v4.3.2 §4) ----
SCEN = {
    "Conservateur": dict(r=0.02, alpha=0.062, covT=0.20, P_coop_T=1.359, fonds_target=0.092,
                         giniT=0.250, bnbT=63.0,
                         emis_milestones={0:0,4:0,10:-0.20,15:-0.33,20:-0.45}),
    "Reference":    dict(r=0.04, alpha=0.45, covT=0.65, P_coop_T=1.81, fonds_target=0.192,
                         giniT=0.185, bnbT=72.0,
                         emis_milestones={0:0,4:0,10:-0.30,15:-0.50,20:-0.68}),
    "Optimiste":    dict(r=0.06, alpha=0.475, covT=0.80, P_coop_T=2.05, fonds_target=0.235,
                         giniT=0.180, bnbT=74.0,
                         emis_milestones={0:0,4:0,10:-0.40,15:-0.65,20:-0.82}),
}

results = {}
for name, over in SCEN.items():
    p = copy.deepcopy(PARAMS); p.update(over)
    df, fed, masse_year, checks = run(p)
    results[name] = df

ref = results["Reference"]
yrs = ref["annee"].values

# ============================ DASHBOARD ============================
fig = plt.figure(figsize=(13.5, 15))
gs = fig.add_gridspec(4, 2, hspace=0.42, wspace=0.22,
                      top=0.935, bottom=0.05, left=0.07, right=0.965)
fig.suptitle("Modèle RCED v4.4.1 — Tableau de bord de simulation (scénario de Référence)",
             fontsize=15, fontweight="bold", color=BLUE, y=0.975)

# 1) PIB & heures
ax = fig.add_subplot(gs[0, 0])
ax.plot(yrs, ref["PIB_index"], color=BLUE, lw=2.4, label="PIB (index 2026=100)")
ax.set_ylabel("PIB index", color=BLUE); ax.tick_params(axis="y", labelcolor=BLUE)
ax2 = ax.twinx(); ax2.grid(False)
ax2.plot(yrs, ref["H"], color=ORANGE, lw=2.4, ls="--", label="Heures/sem")
ax2.set_ylabel("Heures/sem", color=ORANGE); ax2.tick_params(axis="y", labelcolor=ORANGE)
ax.set_title("PIB (+175 %) et semaine de travail (41 h → 28 h)", fontweight="bold")
ax.annotate("275", (yrs[-1], ref["PIB_index"].iloc[-1]), color=BLUE, fontweight="bold",
            xytext=(-22, 4), textcoords="offset points")
ax2.annotate("28 h", (yrs[-1], ref["H"].iloc[-1]), color=ORANGE, fontweight="bold",
             xytext=(-26, -14), textcoords="offset points")

# 2) Emissions nettes
ax = fig.add_subplot(gs[0, 1])
for name, c, lw in [("Conservateur", GREY, 1.6), ("Reference", GREEN, 2.6), ("Optimiste", BLUE2, 1.6)]:
    d = results[name]
    ax.plot(d["annee"], d["emissions_vs2026"]*100, color=c, lw=lw, label=name)
ax.axhline(0, color="#bbbbbb", lw=.8)
ax.set_title("Émissions nettes vs 2026 (par scénario)", fontweight="bold")
ax.set_ylabel("% vs 2026"); ax.legend(frameon=False, fontsize=8.5)
ax.annotate("−68 %", (yrs[-1], -68), color=GREEN, fontweight="bold",
            xytext=(-30, 4), textcoords="offset points")

# 3) Reallocation de l'emploi (aires empilees)
ax = fig.add_subplot(gs[1, 0])
ax.stackplot(yrs, ref["share_auto"]*100, ref["share_nonauto"]*100,
             colors=["#cfd8e3", GREEN], labels=["Secteur automatisable", "Secteur non automatisable"])
ax.set_title("Bascule de l'emploi (5,0 M constants) : 53/47 → 24/76", fontweight="bold")
ax.set_ylabel("% de l'emploi"); ax.set_ylim(0, 100)
ax.legend(loc="center left", frameon=False, fontsize=8.5)

# 4) Couche 13 — energie finale par usage (Reference)
ax = fig.add_subplot(gs[1, 1])
heat = ref["energie_chauffage"].values
# reconstituer les autres usages a partir de l'index total
total = ref["energie_finale_index"].values
others = total - heat
ax.stackplot(yrs, heat, others, colors=[ORANGE, "#cfd8e3"],
             labels=["Chauffage (rénov.+PAC+sable)", "Mobilité, fret, électricité"])
ax.plot(yrs, total, color=BLUE, lw=2.2, label="Énergie finale (total)")
ax.set_title("Couche 13 — Consommation d'énergie finale : 100 → 75", fontweight="bold")
ax.set_ylabel("Index 2026 = 100"); ax.legend(loc="lower left", frameon=False, fontsize=8.5)
ax.annotate("−25 %", (yrs[-1], total[-1]), color=BLUE, fontweight="bold",
            xytext=(-30, 6), textcoords="offset points")

# 5) Couche 14 — overbuild & curtailment
ax = fig.add_subplot(gs[2, 0])
ax.plot(yrs, ref["overbuild_sans_partage"], color=GREY, lw=2, ls="--", label="Sans partage (stockage seul)")
ax.plot(yrs, ref["overbuild"], color=BLUE, lw=2.6, label="Avec réseau emboîté")
ax.fill_between(yrs, ref["overbuild"], ref["overbuild_sans_partage"], color=BLUE2, alpha=.12)
ax.set_title("Couche 14 — Surdimensionnement requis (×) pour 100 % renouvelable", fontweight="bold")
ax.set_ylabel("Facteur d'overbuild"); ax.legend(frameon=False, fontsize=8.5)
axb = ax.twinx(); axb.grid(False)
axb.plot(yrs, ref["curtailment"]*100, color=GREEN, lw=1.8, ls=":")
axb.set_ylabel("Curtailment (%)", color=GREEN); axb.tick_params(axis="y", labelcolor=GREEN)

# 6) Comparaison des scenarios (barres A20)
ax = fig.add_subplot(gs[2, 1])
labels = ["PIB\n(index)", "BNB\n(/100)", "Gini\n(×100)", "Heures", "Fonds\n(% PIB)", "Énergie\nfinale"]
def endrow(d):
    return [d["PIB_index"].iloc[-1], d["bnb"].iloc[-1], d["gini"].iloc[-1]*100,
            d["H"].iloc[-1], d["fonds_pct_PIB"].iloc[-1]*100, d["energie_finale_index"].iloc[-1]]
x = np.arange(len(labels)); w = 0.26
ax.bar(x-w, endrow(results["Conservateur"]), w, color="#cfd8e3", label="Conservateur")
ax.bar(x,   endrow(results["Reference"]),    w, color=GREEN,     label="Référence")
ax.bar(x+w, endrow(results["Optimiste"]),    w, color=BLUE2,     label="Optimiste")
ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8.5)
ax.set_title("Comparaison des scénarios à l'Année 20", fontweight="bold")
ax.legend(frameon=False, fontsize=8.5)

# 7) Partie II — propagation, epsilon, deux horloges
ax = fig.add_subplot(gs[3, 0])
_, fed, masse_year, _ = run(copy.deepcopy(PARAMS))
ax.plot(fed["annee"], fed["propagation"]*100, color=BLUE, lw=2.4, label="Propagation (% masse critique)")
ax.axhline(50, color=GREY, ls=":", lw=1)
ax.fill_between(fed["annee"], 0, 100, where=fed["epsilon"]>0, color=GREEN, alpha=.10,
                label="ε actif (contribution fédérale)")
ax.axvline(2028, color=ORANGE, ls="--", lw=1.5)
ax.annotate("Registre carbone\n(horloge mince) 2028", (2028, 12), color=ORANGE, fontsize=8,
            xytext=(6, 0), textcoords="offset points")
ax.axvline(masse_year, color=GREEN, ls="--", lw=1.5)
ax.annotate(f"Masse critique\n(horloge épaisse) {masse_year}", (masse_year, 70), color=GREEN, fontsize=8,
            xytext=(-96, 0), textcoords="offset points")
ax.set_title("Partie II (horizon) — Deux horloges : carbone vite, fédération lentement", fontweight="bold")
ax.set_ylabel("%"); ax.set_ylim(0, 100); ax.legend(loc="upper left", frameon=False, fontsize=8)

# 8) Synthese textuelle
ax = fig.add_subplot(gs[3, 1]); ax.axis("off")
A20 = ref.iloc[-1]
txt = (
    "SYNTHÈSE — Année 20, Référence\n"
    "──────────────────────────────\n"
    f"PIB                 +175 %  (index {A20['PIB_index']:.0f})\n"
    f"Semaine de travail  {A20['H']:.1f} h\n"
    f"Gini                {A20['gini']:.3f}\n"
    f"BNB                 {A20['bnb']:.0f}/100\n"
    f"Fonds Souverain     {A20['fonds_pct_PIB']*100:.1f} % du PIB\n"
    f"Émissions nettes    {A20['emissions_vs2026']*100:.0f} %\n"
    "──────────────────────────────\n"
    "NOUVEAU v4.4.1\n"
    f"Énergie finale      {A20['energie_finale_index']:.0f}  (−25 %)\n"
    f"  dont chauffage    {A20['energie_chauffage']:.0f}  (était 45)\n"
    f"Overbuild requis    {A20['overbuild']:.2f}× (vs {A20['overbuild_sans_partage']:.2f}×)\n"
    f"Capacité économisée {A20['capacite_a_construire_economisee_%']:.0f} %\n"
    f"Curtailment         {A20['curtailment']*100:.0f} %  (était 18 %)\n"
    f"Chaleur sur sable   {A20['sable_part_chaleur']*100:.0f} %\n"
    "──────────────────────────────\n"
    "Contrôles de cohérence : 7/7 PASS"
)
ax.text(0.0, 1.0, txt, va="top", ha="left", family="monospace", fontsize=9.5,
        color="#222222", transform=ax.transAxes,
        bbox=dict(boxstyle="round,pad=0.6", fc="#f4f7fb", ec=BLUE2, lw=1.2))

fig.savefig("dashboard_v441.png", dpi=130, bbox_inches="tight", facecolor="white")
print("dashboard_v441.png ecrit")

# ---- tableau comparatif scenarios ----
comp = pd.DataFrame({
    name: {
        "PIB index": round(d["PIB_index"].iloc[-1]),
        "BNB /100": round(d["bnb"].iloc[-1]),
        "Gini": round(d["gini"].iloc[-1], 3),
        "Heures/sem": round(d["H"].iloc[-1], 1),
        "Fonds % PIB": round(d["fonds_pct_PIB"].iloc[-1]*100, 1),
        "Emissions vs2026 %": round(d["emissions_vs2026"].iloc[-1]*100),
        "Energie finale (idx)": round(d["energie_finale_index"].iloc[-1]),
        "Overbuild x": round(d["overbuild"].iloc[-1], 2),
    } for name, d in results.items()
}).T
comp.to_csv("scenarios_v441.csv")
print("\nCOMPARAISON DES SCENARIOS (A20)\n" + "="*70)
print(comp.to_string())
